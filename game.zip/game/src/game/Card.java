package game;


public class Card{
	private String path;//pathOfImage
	private int value;//A=1,J=11
	private int score;//karo10=3
	
	
	public Card() {
		// TODO Auto-generated constructor stub
	}
	public Card(String path,int  value,int score){
		this.path=path;	
		this.value=value;
		this.score=score;
	}
	public Card(String path){
		this.path=path;	
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}

	public String toString() {
		// TODO Auto-generated method stub
		return "(path:"+path+", value:" +value+" score:" +score+")\n";
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
}
