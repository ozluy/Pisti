package game;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.Timer;





public class Pisti extends JFrame implements ActionListener {
	public Timer timer;
	//Cards
	//Karo
	
	Card karoA=new Card("cards/karo/karoA.png", 1, 1);
	Card karo2=new Card("cards/karo/karo2.png", 2, 0);
	Card karo3=new Card("cards/karo/karo3.png", 3, 0);
	Card karo4=new Card("cards/karo/karo4.png", 4, 0);
	Card karo5=new Card("cards/karo/karo5.png", 5, 0);
	Card karo6=new Card("cards/karo/karo6.png", 6, 0);
	Card karo7=new Card("cards/karo/karo7.png", 7, 0);
	Card karo8=new Card("cards/karo/karo8.png", 8, 0);
	Card karo9=new Card("cards/karo/karo9.png", 9, 0);
	Card karo10=new Card("cards/karo/karo10.png", 10, 3);
	Card karoJ=new Card("cards/karo/karoJ.png", 11, 1);
	Card karoQ=new Card("cards/karo/karoQ.png", 12, 0);
	Card karoK=new Card("cards/karo/karoK.png", 13, 0);
	//Maça
	Card macaA=new Card("cards/maca/macaA.png", 1, 1);
	Card maca2=new Card("cards/maca/maca2.png", 2, 0);
	Card maca3=new Card("cards/maca/maca3.png", 3, 0);
	Card maca4=new Card("cards/maca/maca4.png", 4, 0);
	Card maca5=new Card("cards/maca/maca5.png", 5, 0);
	Card maca6=new Card("cards/maca/maca6.png", 6, 0);
	Card maca7=new Card("cards/maca/maca7.png", 7, 0);
	Card maca8=new Card("cards/maca/maca8.png", 8, 0);
	Card maca9=new Card("cards/maca/maca9.png", 9, 0);
	Card maca10=new Card("cards/maca/maca10.png", 10, 0);
	Card macaJ=new Card("cards/maca/macaJ.png", 11, 1);
	Card macaQ=new Card("cards/maca/macaQ.png", 12, 0);
	Card macaK=new Card("cards/maca/macaK.png", 13, 0);
	
	//Kupa
	Card kupaA=new Card("cards/kupa/kupaA.png", 1, 1);
	Card kupa2=new Card("cards/kupa/kupa2.png", 2, 0);
	Card kupa3=new Card("cards/kupa/kupa3.png", 3, 0);
	Card kupa4=new Card("cards/kupa/kupa4.png", 4, 0);
	Card kupa5=new Card("cards/kupa/kupa5.png", 5, 0);
	Card kupa6=new Card("cards/kupa/kupa6.png", 6, 0);
	Card kupa7=new Card("cards/kupa/kupa7.png", 7, 0);
	Card kupa8=new Card("cards/kupa/kupa8.png", 8, 0);
	Card kupa9=new Card("cards/kupa/kupa9.png", 9, 0);
	Card kupa10=new Card("cards/kupa/kupa10.png", 10, 0);
	Card kupaJ=new Card("cards/kupa/kupaJ.png", 11, 1);
	Card kupaQ=new Card("cards/kupa/kupaQ.png", 12, 0);
	Card kupaK=new Card("cards/kupa/kupaK.png", 13, 0);
	
	//Sinek
	Card sinekA=new Card("cards/sinek/sinekA.png", 1, 1);
	Card sinek2=new Card("cards/sinek/sinek2.png", 2, 2);
	Card sinek3=new Card("cards/sinek/sinek3.png", 3, 0);
	Card sinek4=new Card("cards/sinek/sinek4.png", 4, 0);
	Card sinek5=new Card("cards/sinek/sinek5.png", 5, 0);
	Card sinek6=new Card("cards/sinek/sinek6.png", 6, 0);
	Card sinek7=new Card("cards/sinek/sinek7.png", 7, 0);
	Card sinek8=new Card("cards/sinek/sinek8.png", 8, 0);
	Card sinek9=new Card("cards/sinek/sinek9.png", 9, 0);
	Card sinek10=new Card("cards/sinek/sinek10.png", 10, 0);
	Card sinekJ=new Card("cards/sinek/sinekJ.png", 11, 1);
	Card sinekQ=new Card("cards/sinek/sinekQ.png", 12, 0);
	Card sinekK=new Card("cards/sinek/sinekK.png", 13, 0);
	Card cards[]={macaA,maca2,maca3,maca4,maca5,maca6,maca7,maca8,maca9,maca10,macaJ,macaQ,macaK,
			sinekA,sinek2,sinek3,sinek4,sinek5,sinek6,sinek7,sinek8,sinek9,sinek10,sinekJ,sinekQ,sinekK,
			kupaA,kupa2,kupa3,kupa4,kupa5,kupa6,kupa7,kupa8,kupa9,kupa10,kupaJ,kupaQ,kupaK,
			karoA,karo2,karo3,karo4,karo5,karo6,karo7,karo8,karo9,karo10,karoJ,karoQ,karoK};
	//Suffle deste
	ArrayList<Card> deste=new ArrayList<Card>(Arrays.asList(cards));
	ArrayList<Card> tableCards=new ArrayList<Card>();
	ArrayList<Card> myDeste=new ArrayList<Card>();
	ArrayList<Card> yourDeste=new ArrayList<Card>();
	ArrayList<Card> yourCards=new ArrayList<Card>();
	ArrayList<Card> myCards=new ArrayList<Card>();
	//Timer timer=new Timer(2000, this);
	//Closed Card
	Card closed=new Card("cards/closedcard.png", 0,0);
	Card rclosed=new Card("cards/rotatedclosedcard.png", 0,0);
	Card selectedByMe=new Card();
	Card selectedByYou=new Card();
	JLabel labelResultYours;
	JLabel labelResultComputer;
	JLabel computerThinking;
	//Pişti Counter
	int myPisti=0;
	int yourPisti=0;
	String lastGetter="";
	int dealCount=0;
	
	//who will play(who's turn)
	int whoSTurn=1;
	
	//Menu
	JMenuBar mb;	
	JMenu setting,tableColors;
	JMenuItem redesign,exit,how,about,scoring;
	JMenuItem colorgreen,colorblue,colordarkgray,colorblack,colorandom;
	JButton mybutton1,mybutton2,mybutton3,mybutton4,yourbutton1,yourbutton2,yourbutton3,yourbutton4,yourvbutton1,yourvbutton2,yourvbutton3,yourvbutton4;
	JButton  buttonMiddle1,buttonMiddle2,buttonMiddle3,buttonMiddle4, buttonDeste,buttonStart,buttonDeal, buttonMyDeste, buttonYourDeste;
	
	int bMiddle1=1,bMiddle2=1,bMiddle3=1;
	//
public Pisti() {
	//LAbels
	timer=new Timer(2000, this);
	labelResultYours=new JLabel();
	labelResultYours.setForeground(Color.WHITE);
	labelResultYours.setSize(500, 50);
	labelResultYours.setLocation(750,350);
	add(labelResultYours);
	labelResultComputer=new JLabel();
	labelResultComputer.setForeground(Color.YELLOW);
	labelResultComputer.setSize(500, 50);
	labelResultComputer.setLocation(750,50);
	add(labelResultComputer);	
	
	computerThinking=new JLabel("The computer is processing.");
	computerThinking.setForeground(Color.YELLOW);
	Font font=new Font("hello", Font.BOLD, 15);
	computerThinking.setFont(font);
	computerThinking.setSize(300, 50);
	computerThinking.setLocation(300,50);
	computerThinking.setVisible(false);
	add(computerThinking);	
	
	
	//Start
	buttonStart =new JButton("Start");
	buttonStart.setSize(90, 20);
	buttonStart.setLocation(40, 40);
	add(buttonStart);
	//Deal Button
	buttonDeal =new JButton("Deal");
	buttonDeal.setSize(90, 20);
	buttonDeal.setLocation(40, 80);
	buttonDeal.setEnabled(false);
	//add(buttonDeal);
	
	//Deste Butonu
	buttonDeste=new JButton();
	buttonDeste.setIcon(new ImageIcon(getClass().getResource(closed.getPath())));
	buttonDeste.setSize(73,100);
	buttonDeste.setLocation(40, 250);	
	add(buttonDeste);
	
	buttonMyDeste=new JButton();
	buttonMyDeste.setIcon(new ImageIcon(getClass().getResource(rclosed.getPath())));
	buttonMyDeste.setSize(100,73);
	buttonMyDeste.setLocation(800, 400);	
	buttonMyDeste.setVisible(false);
	add(buttonMyDeste);
	
	buttonYourDeste=new JButton();
	buttonYourDeste.setIcon(new ImageIcon(getClass().getResource(rclosed.getPath())));
	buttonYourDeste.setSize(100,73);
	buttonYourDeste.setLocation(800, 100);	
	buttonYourDeste.setVisible(false);
	add(buttonYourDeste);
	
	mybutton1=new JButton();
	mybutton2=new JButton();
	mybutton3=new JButton();
	mybutton4=new JButton();
	add(mybutton1);
	add(mybutton2);
	add(mybutton3);
	add(mybutton4);
	
	yourbutton1=new JButton();
	yourbutton2=new JButton();
	yourbutton3=new JButton();
	yourbutton4=new JButton();
	add(yourbutton1);
	add(yourbutton2);
	add(yourbutton3);
	add(yourbutton4);
	yourvbutton1=new JButton();
	yourvbutton2=new JButton();
	yourvbutton3=new JButton();
	yourvbutton4=new JButton();
	/*add(yourvbutton1);
	add(yourvbutton2);
	add(yourvbutton3);
	add(yourvbutton4);  */
	
	buttonMiddle1=new JButton();
	buttonMiddle2=new JButton();	
	buttonMiddle3=new JButton();	
	buttonMiddle4=new JButton();
	add(buttonMiddle4);	
	add(buttonMiddle3);
	add(buttonMiddle2);
	add(buttonMiddle1);
	
	
	
	// TODO Auto-generated constructor stub
	getContentPane().setLayout(null);
	setTitle("Pisti");
	setSize(1000, 600);
	setVisible(true);
	getContentPane().setBackground(Color.darkGray);
	setResizable(false);
	//Cards
	
	
	 //Menu
	mb=new JMenuBar();
	mb.setSize(100, 20);
	mb.setLocation(0, 0);
	setJMenuBar(mb);
	setting=new JMenu("Settings");
	tableColors=new JMenu("Colors");
	mb.add(setting);
	mb.add(tableColors);
	
	//
	redesign=new JMenuItem("Replay");
	exit=new JMenuItem("Exit");
	how=new JMenuItem("How to Play");
	about=new JMenuItem("About Game");
	scoring=new JMenuItem("Scoring");
	//
	setting.add(redesign);
	setting.add(how);
	setting.add(about);	
	setting.add(scoring);
	setting.add(exit);
	colorgreen=new JMenuItem("Green");
	colorblack=new JMenuItem("Black");
	colorblue=new JMenuItem("Blue");
	colordarkgray=new JMenuItem("Dark Gray");
	colorandom=new JMenuItem("Random");
	tableColors.add(colorblack);
	tableColors.add(colorblue);
	tableColors.add(colordarkgray);
	tableColors.add(colorgreen);
	tableColors.add(colorandom);
	
	
	//Adding Actions
	
	exit.addActionListener(this);
	scoring.addActionListener(this);
	mybutton1.addActionListener(this);
	mybutton2.addActionListener(this);
	mybutton3.addActionListener(this);
	mybutton4.addActionListener(this);
	buttonMiddle1.addActionListener(this);
	buttonStart.addActionListener(this);
	buttonDeste.addActionListener(this);
	buttonDeal.addActionListener(this);
	redesign.addActionListener(this);
	colorandom.addActionListener(this);
	colorblack.addActionListener(this);
	colorblue.addActionListener(this);
	colorgreen.addActionListener(this);
	colordarkgray.addActionListener(this); 
	about.addActionListener(this);
}
/*****************Main***************************************************************************************/
public static void main(String[] args) {
	new Pisti();
	
}
	public void tableState(){
			if(tableCards.size()>=4){
				
				
				buttonMiddle3.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-2).getPath())));				
				buttonMiddle2.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-3).getPath())));
				buttonMiddle1.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-4).getPath())));
				
				//
				if(buttonMiddle1.isVisible()==false){					
					buttonMiddle1.setVisible(true);					
				}
				
			}
			if(tableCards.size()==3){
				
				buttonMiddle3.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-2).getPath())));				
				buttonMiddle2.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-3).getPath())));
				//
				if(buttonMiddle2.isVisible()==false){					
					buttonMiddle2.setVisible(true);					
					}
			}
			if(tableCards.size()==2){
				
				buttonMiddle3.setIcon(new ImageIcon(getClass().getResource(tableCards.get(tableCards.size()-2).getPath())));
				
				if(buttonMiddle3.isVisible()==false){					
					buttonMiddle3.setVisible(true);					
					}
			}
	}
	public void buttonDealAction(){
		if(yourCards.size()==0){			
			if(deste.size()==0){
				;
			}
			else{
			dealCount++;
			if(dealCount==5){
				buttonDeal.setEnabled(false);
				buttonDeste.setVisible(false);
			}
			myCards.clear();
			Card c1=deste.remove(0);
			Card c2=deste.remove(0);
			Card c3=deste.remove(0);
			Card c4=deste.remove(0);
			myCards.add(c1);
			myCards.add(c2);
			myCards.add(c3);
			myCards.add(c4);
			showMyCards(c1.getPath(), c2.getPath(), c3.getPath(), c4.getPath());
			//your cards
			Card y1=deste.remove(0);			
			Card y2=deste.remove(0);
			Card y3=deste.remove(0);
			Card y4=deste.remove(0);
			yourCards.add(y1);
			yourCards.add(y2);
			yourCards.add(y3);
			yourCards.add(y4);
			//Visible
			showYourCards(closed.getPath(), y1.getPath(), y2.getPath(), y3.getPath(), y4.getPath());			
			mybutton1.setVisible(true);
			mybutton2.setVisible(true);
			mybutton3.setVisible(true);
			mybutton4.setVisible(true);
			
			
			}
	}
	}
	public void buttonStartAction(){
		buttonStart.setEnabled(false);
		buttonDeal.setEnabled(true);			
		Card cclosed=new Card("cards/closedcard.png", 0, 0);			
		Collections.shuffle(deste);			
		//table Cards
		Card t1=deste.remove(0);
		Card t2=deste.remove(0);
		Card t3=deste.remove(0);
		Card t4=deste.remove(0);
		tableCards.add(t1);
		tableCards.add(t2);
		tableCards.add(t3);
		tableCards.add(t4);
		showTableCards(t1.getPath(), t2.getPath(), t3.getPath(), t4.getPath());			
		//my Cards			
		Card c1=deste.remove(0);
		Card c2=deste.remove(0);
		Card c3=deste.remove(0);
		Card c4=deste.remove(0);
		myCards.add(c1);
		myCards.add(c2);
		myCards.add(c3);
		myCards.add(c4);
		showMyCards(c1.getPath(), c2.getPath(), c3.getPath(), c4.getPath());
		//yourcards
		Card y1=deste.remove(0);			
		Card y2=deste.remove(0);
		Card y3=deste.remove(0);
		Card y4=deste.remove(0);
		yourCards.add(y1);
		yourCards.add(y2);
		yourCards.add(y3);
		yourCards.add(y4);
		showYourCards(cclosed.getPath(),y1.getPath(),y2.getPath(),y3.getPath(),y4.getPath());
		
		buttonMyDeste.setVisible(false);
		buttonYourDeste.setVisible(false);
		
	}
	public void setVisibleTableCards(Boolean b){
		buttonMiddle1.setVisible(b);
		buttonMiddle2.setVisible(b);
		buttonMiddle3.setVisible(b);
		buttonMiddle4.setVisible(b);
	}
/******************************action******************************************************************************/

	public void actionYours4(){
		if(yourCards.size()==4){
			ArrayList<Card> tmp=new ArrayList<Card>();
			tmp.add(yourCards.get(0));
			tmp.add(yourCards.get(1));
			tmp.add(yourCards.get(2));
			tmp.add(yourCards.get(3));
			
			if(whoSTurn==0){
				if(tableCards.size()>=2){
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(3).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(3));
							tableCards.clear();
							yourCards.remove(3);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(3).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(3));
							tableCards.clear();
							yourCards.remove(3);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
				}
				
				//tablecard.size=1
				if(tableCards.size()==1){

					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							if(yourCards.get(0).getValue()==11){
							yourPisti=yourPisti+2;
							}
							else yourPisti++;
							yourCards.remove(0);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							if(yourCards.get(1).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(1);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							if(yourCards.get(2).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(2);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					
					if(whoSTurn==0){
						if(tmp.get(3).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(3));
							tableCards.clear();
							if(yourCards.get(3).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(3);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(3).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(3));
							tableCards.clear();
							yourCards.remove(3);
							yourbutton1.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
				}
			}
		}		
		if(whoSTurn==0){
			if(whoSTurn==0){
				if(yourCards.size()==4){	
				if(yourCards.get(0).getValue()==11&&tableCards.size()==0){
					yourbutton1.setVisible(false);					
					buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(1).getPath())));
					buttonMiddle4.setVisible(true);
					tableCards.add(yourCards.get(1));
					yourCards.remove(1);
					whoSTurn=1;
				}
				}
			}
			if(whoSTurn==0){
			if(yourCards.size()==4){		
				yourbutton1.setVisible(false);
				buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(0).getPath())));
				buttonMiddle4.setVisible(true);
				tableCards.add(yourCards.get(0));
				yourCards.remove(0);
				whoSTurn=1;
		}
			}
		}
		
		
	}
	
	public void actionYours3(){
		if(yourCards.size()==3){
			ArrayList<Card> tmp=new ArrayList<Card>();
			tmp.add(yourCards.get(0));
			tmp.add(yourCards.get(1));
			tmp.add(yourCards.get(2));
			if(whoSTurn==0){
				if(tableCards.size()>=2){
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
				}
				
				//tablecard.size=1
				if(tableCards.size()==1){

					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							if(yourCards.get(0).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(0);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							if(yourCards.get(1).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(1);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							if(yourCards.get(2).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(2);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					
					
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(2).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(2));
							tableCards.clear();
							yourCards.remove(2);
							yourbutton2.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}					
				}
			}
		}		
		if(whoSTurn==0){
			if(whoSTurn==0){
				if(yourCards.size()==3){
				if(yourCards.get(0).getValue()==11&&tableCards.size()==0){
					yourbutton2.setVisible(false);
					buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(1).getPath())));
					buttonMiddle4.setVisible(true);
					tableCards.add(yourCards.get(1));
					yourCards.remove(1);
					whoSTurn=1;
				}
				}
			}
			if(whoSTurn==0){
			if(yourCards.size()==3){
				yourbutton2.setVisible(false);
				buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(0).getPath())));
				buttonMiddle4.setVisible(true);
				tableCards.add(yourCards.get(0));
				yourCards.remove(0);
				whoSTurn=1;
		}
			}
		}
	}
			
	public void actionYours2(){
		if(yourCards.size()==2){
			ArrayList<Card> tmp=new ArrayList<Card>();
			tmp.add(yourCards.get(0));
			tmp.add(yourCards.get(1));
			if(whoSTurn==0){
				if(tableCards.size()>=2){
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
					
					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
				}
				
				//tablecard.size=1
				if(tableCards.size()==1){

					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							if(yourCards.get(0).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(0);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							if(yourCards.get(1).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(1);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
							
						}
					}
					
					
					
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					if(whoSTurn==0){
						if(tmp.get(1).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(1));
							tableCards.clear();
							yourCards.remove(1);
							yourbutton3.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
									
				}
			}
		}		
		if(whoSTurn==0){
			if(whoSTurn==0){
				if(yourCards.size()==2){
				if(yourCards.get(0).getValue()==11&&tableCards.size()==0){
					yourbutton3.setVisible(false);
					buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(1).getPath())));
					buttonMiddle4.setVisible(true);
					tableCards.add(yourCards.get(1));
					yourCards.remove(1);
					whoSTurn=1;
				}
				}
			}
			if(whoSTurn==0){
			if(yourCards.size()==2){	
				yourbutton3.setVisible(false);
				buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(0).getPath())));
				buttonMiddle4.setVisible(true);
				tableCards.add(yourCards.get(0));
				yourCards.remove(0);
				whoSTurn=1;
		}
		}
		}
		
		
	}
	public void actionYours1(){
		
		if(yourCards.size()==1){
			ArrayList<Card> tmp=new ArrayList<Card>();
			tmp.add(yourCards.get(0));
			if(whoSTurn==0){
				if(tableCards.size()>=2){
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton4.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
										
					
					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton4.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
				}
				
				//tablecard.size=1
				if(tableCards.size()==1){

					//if cards are same
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==tableCards.get(tableCards.size()-1).getValue()){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							if(yourCards.get(0).getValue()==11){
								yourPisti=yourPisti+2;
								}
								else yourPisti++;
							yourCards.remove(0);
							yourbutton4.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
					
					
					
					//if card is Joker
					if(whoSTurn==0){
						if(tmp.get(0).getValue()==11){
							yourDeste.addAll(tableCards);
							yourDeste.add(tmp.get(0));
							tableCards.clear();
							yourCards.remove(0);
							yourbutton4.setVisible(false);
							setVisibleTableCards(false);
							lastGetter="you";
							whoSTurn=1;
						}
					}
					
									
				}
			}
		}		
		if(whoSTurn==0){
			if(yourCards.size()==1){	
				yourbutton4.setVisible(false);
				buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(yourCards.get(0).getPath())));
				buttonMiddle4.setVisible(true);
				tableCards.add(yourCards.get(0));
				yourCards.remove(0);
				whoSTurn=1;
		}
		}
		
	}

	public void actionMine(){			
			if(tableCards.size()>1){
				if(whoSTurn==1){
					if(tableCards.get(tableCards.size()-2).getValue()==selectedByMe.getValue()&&tableCards.size()>2){						
						myDeste.addAll(tableCards);
						tableCards.clear();
						setVisibleTableCards(false);
						lastGetter="me";
						whoSTurn=0;			
					}
				}
				if(whoSTurn==1){
					if(tableCards.get(tableCards.size()-2).getValue()==selectedByMe.getValue()&&tableCards.size()==2){						
						myDeste.addAll(tableCards);
						tableCards.clear();
						myPisti++;
						setVisibleTableCards(false);
						lastGetter="me";
						whoSTurn=0;	
					}
				}
				if(whoSTurn==1){
					if(selectedByMe.getValue()==11){						
						myDeste.addAll(tableCards);
						tableCards.clear();
						setVisibleTableCards(false);
						lastGetter="me";
						whoSTurn=0;	
					}
				}
				else {
					if(whoSTurn==1){
						whoSTurn=0;
					}					
				}	
							
			}	
			if(whoSTurn==1){
				whoSTurn=0;	
			}
	}
	public void showResults(){
			if(lastGetter=="you"){
				yourDeste.addAll(tableCards);
				tableCards.clear();
			}
			if(lastGetter=="me"){
				myDeste.addAll(tableCards);
				tableCards.clear();
			}
			
			int myresults=0;
			int yourresults=0;
			for (int i = 0; i < myDeste.size(); i++) {
				myresults+=myDeste.get(i).getScore();
			}
			myresults+=myPisti*10;
			for (int i = 0; i < yourDeste.size(); i++) {
				yourresults+=yourDeste.get(i).getScore();
			}
			yourresults+=yourPisti*10;
			if(myDeste.size()>26){
				myresults+=3;
			}
			if(yourDeste.size()>26){
				yourresults+=3;
			}
			labelResultYours.setText("your score: "+ myresults +", number of pisti: "+myPisti);
			labelResultComputer.setText("computer score: "+yourresults+", number of pisti: "+yourPisti);
	}
	public void showMyCards(String c1,String c2,String c3,String c4){
		mybutton1.setLocation(200,400);
		mybutton1.setSize(73,100);
		mybutton1.setIcon(new ImageIcon(getClass().getResource(c1)));
		
		//
		mybutton2.setLocation(300,400);
		mybutton2.setSize(73,100);
		mybutton2.setIcon(new ImageIcon(getClass().getResource(c2)));
		
		//
		mybutton3.setLocation(400,400);
		mybutton3.setSize(73,100);
		mybutton3.setIcon(new ImageIcon(getClass().getResource(c3)));
		
		//
		mybutton4.setLocation(500,400);
		mybutton4.setSize(73,100);
		mybutton4.setIcon(new ImageIcon(getClass().getResource(c4)));
		
		//Visible
		mybutton1.setVisible(true);
		mybutton2.setVisible(true);
		mybutton3.setVisible(true);
		mybutton4.setVisible(true);
		
	}
	public void showTableCards(String t1,String t2,String t3,String t4){
		//1
		if(buttonMiddle1.isEnabled()==true){
			buttonMiddle1.setEnabled(false);
		}
		buttonMiddle1.setSize(73,100);
		buttonMiddle1.setLocation(225, 250);
		buttonMiddle1.setIcon(new ImageIcon(getClass().getResource(t1)));
	
		
		//2
		if(buttonMiddle2.isEnabled()==true){
			buttonMiddle2.setEnabled(false);
		}
		buttonMiddle2.setSize(73,100);
		buttonMiddle2.setLocation(300, 250);
		buttonMiddle2.setIcon(new ImageIcon(getClass().getResource(t2)));
	
		
		//3
		
		if(buttonMiddle3.isEnabled()==true){
			buttonMiddle3.setEnabled(false);
		}
		buttonMiddle3.setSize(73,100);
		buttonMiddle3.setLocation(375, 250);
		buttonMiddle3.setIcon(new ImageIcon(getClass().getResource(t3)));
		
		
		//4
	
		buttonMiddle4.setEnabled(true);
		buttonMiddle4.setSize(73,100);
		buttonMiddle4.setLocation(450, 250);
		buttonMiddle4.setIcon(new ImageIcon(getClass().getResource(t4)));
		
		//setting Visible
		if(buttonMiddle1.isVisible()==false){
		buttonMiddle1.setVisible(true);
		}
		if(buttonMiddle2.isVisible()==false){
		buttonMiddle2.setVisible(true);
		}
		if(buttonMiddle3.isVisible()==false){
		buttonMiddle3.setVisible(true);
		}
		if(buttonMiddle4.isVisible()==false){
		buttonMiddle4.setVisible(true);
		}
		
	}
	public void showYourCards(String y1,String v1,String v2,String v3,String v4){
		yourbutton1.setLocation(200,100);
		yourbutton1.setSize(73,100);
		yourbutton1.setIcon(new ImageIcon(getClass().getResource(y1)));
		
		yourvbutton1.setLocation(200,80);
		yourvbutton1.setSize(73,100);
		yourvbutton1.setIcon(new ImageIcon(getClass().getResource(v1)));
		
		
		//
		yourbutton2.setLocation(300,100);
		yourbutton2.setSize(73,100);
		yourbutton2.setIcon(new ImageIcon(getClass().getResource(y1)));
		
		yourvbutton2.setLocation(300,80);
		yourvbutton2.setSize(73,100);
		yourvbutton2.setIcon(new ImageIcon(getClass().getResource(v2)));
		
		//
		yourbutton3.setLocation(400,100);
		yourbutton3.setSize(73,100);
		yourbutton3.setIcon(new ImageIcon(getClass().getResource(y1)));
		
		yourvbutton3.setLocation(400,80);
		yourvbutton3.setSize(73,100);
		yourvbutton3.setIcon(new ImageIcon(getClass().getResource(v3)));
		
		//
		yourbutton4.setLocation(500,100);
		yourbutton4.setSize(73,100);
		yourbutton4.setIcon(new ImageIcon(getClass().getResource(y1)));
		
		yourvbutton4.setLocation(500,80);
		yourvbutton4.setSize(73,100);
		yourvbutton4.setIcon(new ImageIcon(getClass().getResource(v4)));
		//setting visible
		yourbutton1.setVisible(true);
		yourbutton2.setVisible(true);
		yourbutton3.setVisible(true);
		yourbutton4.setVisible(true);
		yourvbutton1.setVisible(true);
		yourvbutton2.setVisible(true);
		yourvbutton3.setVisible(true);
		yourvbutton4.setVisible(true);
		
	}
	
	public void actionMyCard(JButton b,int n){	
		
		buttonMiddle4.setIcon(b.getIcon());
		buttonMiddle4.setVisible(true);
		b.setVisible(false);
		tableCards.add(myCards.get(n));
		selectedByMe=myCards.get(n);		
	}		
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int random=new Random().nextInt(200000);
		setTableColor(e, colorandom,Color.getColor("renk",random));
		setTableColor(e, colorblack, Color.BLACK);
		setTableColor(e, colorblue, Color.BLUE);
		setTableColor(e, colorgreen, Color.green);
		setTableColor(e, colordarkgray, Color.DARK_GRAY);
			
		if(e.getSource().equals(exit)){
			System.exit(1);
		}		
		if(e.getSource().equals(buttonStart)){
				buttonStartAction();
				
				//timer.start();
				buttonDealAction();	
				
		}
		if(buttonStart.isEnabled()==false){
			run();
		}
		
		
		if(e.getSource().equals(buttonDeal)){					
				buttonDealAction();			
		}
		if(whoSTurn==1){
			
			if(e.getSource().equals(mybutton1)){			
				actionMyCard(mybutton1, 0);
				actionMine();	
				computerThinking.setVisible(true);
				timer.start();
				
			}
			if(e.getSource().equals(mybutton2)){			
				actionMyCard(mybutton2, 1);
				actionMine();
				computerThinking.setVisible(true);
				timer.start();
			}
			if(e.getSource().equals(mybutton3)){				
				actionMyCard(mybutton3, 2);
				actionMine();
				computerThinking.setVisible(true);
				timer.start();
			}
			if(e.getSource().equals(mybutton4)){			
				actionMyCard(mybutton4, 3);
				actionMine();
				computerThinking.setVisible(true);
				timer.start();
			}
			if(myDeste.size()>0){
				buttonMyDeste.setVisible(true);
			}
			if(myDeste.size()>0&&yourDeste.size()+myDeste.size()!=52){
			labelResultYours.setText(""+ myDeste.size());
			}
			tableState();
			
		}
		if(e.getSource().equals(scoring)){
			JOptionPane.showMessageDialog(this,"" +
					"Each jack = 1 point\n" +
					"Each ace = 1 point \n" +
					"Clubs 2 = 2 points \n" +
					"Diamonds 10 = 3 points\n" +
					"Majority of cards = 3 points \n" +
					"Each pisti = 10 poi" +
					"nts ");
		}
		if(e.getSource().equals(about)){
			JOptionPane.showMessageDialog(this,"This game developed by Yusuf Ozlu.");
		}
		if(e.getSource().equals(redesign)){
			yourPisti=0;
			myPisti=0;
			timer.stop();
			labelResultComputer.setText("");
			labelResultYours.setText("");
			
			buttonDeste.setVisible(true);
			//buttonDeste.setVisible(true);
			deste=new ArrayList<Card>(Arrays.asList(cards));
			Collections.shuffle(deste);
			dealCount=0;
			setVisibleTableCards(false);
			mybutton1.setVisible(false);
			mybutton2.setVisible(false);
			mybutton3.setVisible(false);
			mybutton4.setVisible(false);
			yourbutton1.setVisible(false);
			yourbutton2.setVisible(false);
			yourbutton3.setVisible(false);
			yourbutton4.setVisible(false);
			yourvbutton1.setVisible(false);
			yourvbutton2.setVisible(false);
			yourvbutton3.setVisible(false);
			yourvbutton4.setVisible(false);
			myCards.clear();
			tableCards.clear();
			yourCards.clear();
			myDeste.clear();
			yourDeste.clear();
			whoSTurn=1;
			buttonDeal.setEnabled(false);
			buttonStart.setEnabled(true);
			buttonYourDeste.setVisible(false);
			buttonMyDeste.setVisible(false);
			}		
	}
	
	public void run() {
		// TODO Auto-generated method stub		
		result();		
		
		buttonDealAction();
		actionYours4();
		actionYours3();
		actionYours2();
		actionYours1();
		if(yourDeste.size()>0&&yourDeste.size()+myDeste.size()!=52){
		labelResultComputer.setText(yourDeste.size()+"");
		}
		setTimerDelay();
		tableState();
		if(yourDeste.size()>0){
			buttonYourDeste.setVisible(true);
		}
		timer.stop();
		if(yourCards.size()==0){
			timer.start();
		}
				
		computerThinking.setVisible(false);
	}
	public void setTimerDelay(){
		if(yourCards.size()==1){
			timer.setDelay(1000);
		}
		if(yourCards.size()==4){
			timer.setDelay(2000);
		}
		
	}
	public void result(){		
		if(deste.size()==0&&yourCards.size()==0){		
			setVisibleTableCards(false);
			showResults();
			timer.stop();
			
		}
	}
	public void setTableColor(ActionEvent e,JMenuItem mi,Color c){
		if(e.getSource().equals(mi)){
		getContentPane().setBackground(c);
		}
	}
	
}
